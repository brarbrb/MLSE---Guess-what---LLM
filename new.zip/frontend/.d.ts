// Declare the file types that may be used in our project, in our React app.
declare module '*.png';
declare module '*.jpg';
declare module '*.jpeg';
declare module '*.gif';
declare module '*.svg';
declare module '*.ico';
declare module '*.ttf';
declare module '*.otf';
declare module '*.woff';
declare module '*.mp3';
declare module '*.ogg';
declare module '*.wav';
