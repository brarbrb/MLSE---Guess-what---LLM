// frontend/static/js/room.js
(function () {
  const $  = (s, r=document)=>r.querySelector(s);

  // ----- state -----
  const state = {
    gameId: null,
    user: {},
    timerId: null,
    sockets: null,
    // to drive the waiting->reveal behavior even with polling
    wasWaiting: false
  };

  // ----- DOM refs -----
  const overlay = $("#modal-overlay");
  const modals = {
    describer: $("#modal-describer"),
    waiting:   $("#modal-waiting"),
    winner:    $("#modal-winner"),
  };

  // ----- utils -----
  function getGameId() {
    const m = location.pathname.match(/\/room\/(\d+)/);
    return m ? Number(m[1]) : null;
  }
  function showModal(m){ overlay.hidden=false; m.hidden=false; }
  function hideModal(m){ m.hidden=true; if (![...Object.values(modals)].some(x=>!x.hidden)) overlay.hidden = true; }

  function setBadge(text){ $("#round-status").textContent = text || ""; }
  function setDesc(text){ $("#round-description").textContent = text || "—"; }
  function renderPlayers(list,scores={}){
    const ul=$("#players-list"); ul.innerHTML="";
    (list||[]).forEach(n=>{
      const li=document.createElement("li");
      li.textContent = `${n}: ${scores[n] ?? 0} points`;
      ul.appendChild(li);
    });
  }
  function addChatLine(user,text){
    const box=$("#chat-list");
    const div=document.createElement("div");
    div.className="chat-item";
    div.innerHTML = `<span class="u">${user}</span><span>${text}</span>`;
    box.appendChild(div);
    box.scrollTop = box.scrollHeight;
  }
  function startTimer(iso){
    const el=$("#round-timer");
    if (state.timerId){ clearInterval(state.timerId); state.timerId=null; }
    if (!iso){ el.hidden = true; return; }
    el.hidden = false;
    const start = new Date(iso).getTime();
    state.timerId = setInterval(()=>{
      const d = Date.now()-start;
      const m = Math.floor(d/60000).toString().padStart(2,"0");
      const s = Math.floor((d%60000)/1000).toString().padStart(2,"0");
      el.textContent = `${m}:${s}`;
    }, 250);
  }

  // ----- REST -----
  async function apiGetRoom(){ const r=await fetch(`/api/room/${state.gameId}`); return r.json(); }
  async function apiPutDescription(text){
    const r=await fetch(`/api/room/${state.gameId}/description`, {
      method:"PUT", headers:{ "Content-Type":"application/json" },
      body: JSON.stringify({ description: text })
    }); return r.json();
  }
  async function apiPutGuess(text){
    const r=await fetch(`/api/room/${state.gameId}/guess`, {
      method:"PUT", headers:{ "Content-Type":"application/json" },
      body: JSON.stringify({ guess: text })
    }); return r.json();
  }

  // ----- polling -----
  let pollId=null;
  function startPolling(){
    stopPolling();
    const tick = async () => {
      try {
        const data = await apiGetRoom();
        if (!data || data.error) return;
        applySnapshot(data, { from: "poll" });
      } catch {/* noop */}
    };
    tick();
    pollId = setInterval(tick, 1200);
  }
  function stopPolling(){ if (pollId) clearInterval(pollId); pollId=null; }

  // ----- sockets (optional) -----
  function setupSockets(){
    if (typeof io === "undefined") return;
    const socket = io();
    state.sockets = socket;

    socket.on("connect", ()=> socket.emit("room:join", { game_id: state.gameId }));

    socket.on("chat:new", (msg)=> addChatLine(msg.user, msg.text));

    socket.on("round:description", (data)=> {
      // live morph for players
      onDescriptionReveal(data?.description || "", data?.startedAt || null);
    });

    socket.on("round:won", (data)=> {
      onWinner(data?.winner, data?.word, data?.elapsedMs);
    });
  }

  // ----- snapshot -> UI -----
  function applySnapshot(d, {from}={}){
    // Server decides who is creator by whether it included secrets
    const hasSecrets = ("targetWord" in d) || ("forbiddenWords" in d);

    // render basics
    renderPlayers(d.players || [], d.scores || {});
    setBadge(d.status || "");
    if (d.description) setDesc(d.description);

    // timer
    if (d.status === "active" && d.startedAt) startTimer(d.startedAt);
    if (d.status !== "active") startTimer(null);

    // modal logic
    if (d.status === "waiting_description") {
      state.wasWaiting = true;

      if (hasSecrets) {
        // CREATOR modal (target + forbidden + textarea)
        $("#modal-target").textContent = d.targetWord || "—";
        const ul = $("#modal-forbidden"); ul.innerHTML="";
        (d.forbiddenWords || []).forEach(w=>{
          const li=document.createElement("li"); li.textContent=w; ul.appendChild(li);
        });
        showModal(modals.describer);
        hideModal(modals.winner);
        hideModal(modals.waiting);
      } else {
        // PLAYER waiting modal
        $("#waiting-title").textContent = "Waiting for description…";
        $("#waiting-text").textContent  = "The describer is preparing a clue.";
        showModal(modals.waiting);
        hideModal(modals.describer);
        hideModal(modals.winner);
      }
    } else if (d.status === "active") {
      // If we transitioned from waiting -> active via POLLING, do the same morph
      if (state.wasWaiting && d.description) {
        onDescriptionReveal(d.description, d.startedAt || null);
      } else {
        hideModal(modals.waiting);
        hideModal(modals.describer);
      }
      state.wasWaiting = false;
    } else if (d.status === "completed") {
      hideModal(modals.waiting);
      hideModal(modals.describer);
      // winner modal will be shown by sockets or when guesser receives REST success
    }
  }

  // ----- behaviors -----
  function onDescriptionReveal(description, startedAt){
    $("#waiting-title").textContent = "Description ready!";
    $("#waiting-text").textContent  = description || "";
    $("#modal-waiting").classList.add("fade-in");
    setDesc(description || "");
    setBadge("active");
    startTimer(startedAt || null);
    setTimeout(()=> hideModal(modals.waiting), 3000);
  }

  function onWinner(winner, word, elapsedMs){
    $("#winner-name").textContent = winner || "Someone";
    $("#winner-word").textContent = word || "";
    $("#winner-time").textContent = (typeof elapsedMs === "number")
      ? `Time: ${(elapsedMs/1000).toFixed(1)}s` : "";
    showModal(modals.winner);
  }

  // ----- forms -----
  function setupForms(){
    // Creator submits description
    $("#describer-form")?.addEventListener("submit", async (e)=>{
      e.preventDefault();
      const txt = $("#description-input").value.trim();
      if (!txt) return;
      const res = await apiPutDescription(txt);
      if (res?.error){
        const p=$("#desc-error");
        p.textContent = res.which
          ? `Description invalid: contains "${res.which}".`
          : (res.error || "Failed to submit.");
        p.hidden = false;
        return;
      }
      $("#desc-error").hidden = true;
      hideModal(modals.describer);
      setDesc(txt);
      setBadge("active");
      startTimer(res?.startedAt || null);
    });

    // Chat / guess (single handler; if sockets exist, also broadcast as chat)
    $("#chat-form")?.addEventListener("submit", async (e)=>{
      e.preventDefault();
      const inp = $("#chat-input");
      const t = inp.value.trim();
      if (!t) return;

      // optimistic chat line
      addChatLine(state.user?.username || "me", t);

      // as chat (if sockets wired)
      if (state.sockets) {
        state.sockets.emit("chat:send", { game_id: state.gameId, text: t });
      }

      // also evaluate as guess via REST (authoritative)
      const res = await apiPutGuess(t);
      if (res?.correct) {
        onWinner(state.user?.username || "You", res.word, res.elapsedMs);
      }
      inp.value = "";
    });

    $("#btn-see-game")?.addEventListener("click", ()=> hideModal(modals.winner));
  }

  // ----- init -----
  (function init(){
    state.gameId = getGameId();
    try { state.user = JSON.parse(localStorage.getItem("currentUser") || "{}"); } catch {}

    if (!state.gameId) return;

    setupForms();
    setupSockets();   // optional; polling still works without it
    startPolling();
  })();
})();
