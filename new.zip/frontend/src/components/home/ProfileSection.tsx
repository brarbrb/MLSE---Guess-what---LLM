import React from 'react';

interface Props {
}

const ProfileSection: React.FC<Props> = () => {
  // Get user data

  // if user is not logged in, return the login form

  return (
    <section>
      <h2>User Data</h2>
      TODO
    </section>
  );
};

export default ProfileSection;
