from .main import create_app  # convenient import
